gizwits_noti_demo
==================
v2.0.0 for netty

Gizwits noti client demo.

## Change log: v2.0.0 (2016/08)
* First version 
