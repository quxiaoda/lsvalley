package com.gizwits.noti2.sslservice.msg;

/**
 * Created by l8611 on 2015/8/24.
 */
public class AlertMsg extends BaseMsg {
    private String event_type;
    private String delivery_id;
    private String event_id;
    private String product_key;
    private String did;
    private String mac;
    private String group_id;
    private long created_at;
}
